## ----setup, include = FALSE, cache = FALSE-------------------------------
knitr::opts_chunk$set(error = TRUE, collapse = TRUE)

## ------------------------------------------------------------------------
identity <- function(x = NULL) {
  x
}

identity
formals(identity)
body(identity)

## ------------------------------------------------------------------------
x <- 1; y <- 3
x + y
`+`(x, y)

## ------------------------------------------------------------------------
`<-`("a", 1) # actually assign() is more powerfull
a

## ------------------------------------------------------------------------
a <- 2 # nothing is printed
(a <- 2)

## ------------------------------------------------------------------------
rm(x) # removing previous instance of object x
exists("x") # make sure x does not exist anymore
y <- mean(x <- round(runif(4, max = 10)))
x


## ------------------------------------------------------------------------
eval(a)
a

## ---- eval= TRUE---------------------------------------------------------
h <- function(x) {
  a <- 2
  x + a
}
h(x = 1)

## ------------------------------------------------------------------------
h <- function(x) {
  a <- 2
  x + a
}
a <- 0
h(x = 1)
a

## ---- eval= FALSE--------------------------------------------------------
## # These calls are all equivalent
## sample(x = 1:10, size = 10, replace = TRUE)
## sample(1:10, 10, TRUE)
## sample(x = 1:10, replace = TRUE, s = 10)

## ------------------------------------------------------------------------
args(write) # Let's display the formal arguments of a function:

## ------------------------------------------------------------------------
SquareRnorm <- function(n, ...) {
rnorm(n = n, ...) ^ 2
}

SquareRnorm(1)
SquareRnorm(1, mean = 200)
SquareRnorm(1, sd = 1000)

## ---- eval = FALSE-------------------------------------------------------
## if (!is.array(x) || length(dn <- dim(x)) < 2L) stop("'x' must be an array of at least two dimensions")

## ------------------------------------------------------------------------
Bet <- function() {                  # Notice that it has no formal argument
  outcome <- sample(c(TRUE, FALSE), 1)
  if(!outcome) return("Looser!")      # Early termination
  cat("You are an oracle!! Here is your reward.\n")
  "100000000 Euros"
}
Bet()

## ------------------------------------------------------------------------
sixnum <- function(x) {
  if (missing(x)) x <- runif(10)
  fiveNum <- fivenum(x)
  count <- length(x)
  list(TukeyFiveNumber = fiveNum, CountOfObs = count)
}
str(sixnum())

## ------------------------------------------------------------------------
oldWd <- setwd(.libPaths()[1])
getwd()
oldWd
setwd(oldWd)

## ------------------------------------------------------------------------
x <- 1
Increment <- function(by = 1) {x <<- x + by ; cat("Incremented 'x'!")}
Increment(by = 2)
x

## ------------------------------------------------------------------------
x <- 1
BetterIncrement <- function(numb, by = 1) {numb <- numb + by}
x <- BetterIncrement(numb = x, by = 2)
x

## ---- eval= FALSE--------------------------------------------------------
## x <- sample(replace = TRUE, 20, x = c(1:10, NA))
## y <- runif(min = 0, max = 1, 20)
## cor(m = "k", y = y, u = "p", x = x)

## ------------------------------------------------------------------------
f <- function(x = ls()) {
  a <- 1
  x
}

## ----ANS01---------------------------------------------------------------
# ls() evaluated inside f:
f()

# ls() evaluated in global environment:
f(ls())

## ------------------------------------------------------------------------
z <- 1
f2 <- function(x = z) {
  z <- 100
  x
}

## ----ANS02---------------------------------------------------------------

f2()
z

## ----ANS03---------------------------------------------------------------
RunDice <- function() {    # How did you call YOUR function BTW?
  ceiling(6*runif(1)) # could have been done with sample()
}
RunDice()

## ----ANS04---------------------------------------------------------------
Untangle <- function(l1 = NULL, l2 = NULL) {
  if (is.null(l1) && is.null(l2)) {l1 <- l2 <- 0} # what happens if called without arguments
  if (is.null(l1)) l1 <- l2                       # deal with the square issue
  if (is.null(l2)) l2 <- l1
  p <- (l1 + l2)*2
  s <- l1*l2
  data.frame(width = min(l1,l2), lenght = max(l1,l2), # decide on what is w and what is l
       perimeter = p, surface = s)
}
# Lets test the function:
Untangle()
Untangle(2)
Untangle(l1 = 2)
Untangle(l2 = 2)
Untangle(l1 = 1 , l2 = 2)
Untangle(l1 = 2 , l2 = 1)


