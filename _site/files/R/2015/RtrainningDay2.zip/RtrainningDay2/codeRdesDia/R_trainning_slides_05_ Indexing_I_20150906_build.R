## ----setup, include = FALSE, cache = FALSE-------------------------------
knitr::opts_chunk$set(error = TRUE, collapse = TRUE)

## ------------------------------------------------------------------------
x <- 101:105 # the ':' is a shorthand for the function seq() that we will see later.
# Name the elements
names(x) <- c("A", "B", "C", "D", "E")
# OR
x <- setNames(101:105, c("A", "B", "C", "D", "E"))
x

## ---- eval= FALSE--------------------------------------------------------
## x[c(2, 3, 3)] # several elements, the same position(s) can occur several times
## x[3:5] # generate a sequence of numerics and subset with it.
## x[c(1, 105)] # out of bound index values generate NAs

## ---- eval=FALSE---------------------------------------------------------
## x[-2] # Everything but the second element.

## ----ANS01, eval= TRUE---------------------------------------------------
x[0]
x[-1]
x[-((length(x)-1):length(x))]

## ---- eval=TRUE----------------------------------------------------------
x[c(TRUE, FALSE, FALSE, TRUE, TRUE)]

x[c(T, F)] # if logical vector is too short, it is recycled.

v <- x[c(T, T, T, T, T, T, T)]
v # if logical vector is too long, NAs are returned

## ------------------------------------------------------------------------
idx <- x > 102 & x <= 104 # logical vector
idx

x[idx]

## ----ANS02---------------------------------------------------------------
x[ abs(x - mean(x)) > sd(x) ]

## ----ANS03---------------------------------------------------------------
v[ !is.na(v) ]

## ------------------------------------------------------------------------
x[c("A", "A", "D")]

## ------------------------------------------------------------------------
idx <- match(c("A", "A", "D"), names(x))
idx
x[idx]

## ------------------------------------------------------------------------
v <- c("three", "four", "one", "two", "three", "one", "four") # Vector to be recoded.
lookUp <- c(one = "un", two = "deux", three = "trois", four = "quatre") # look-up table

v

unname(lookUp[v]) # recoding and getting ride of names

## ------------------------------------------------------------------------
w <- as.factor(v)
levels(w)

levels(w) <- c("quatre", "un", "trois", "deux")

as.character(w)

## ------------------------------------------------------------------------
oldX <- x
x[1] <- 1

x < 103
x[ x < 103 ] <- 0

x

## ------------------------------------------------------------------------
x[1:4] <- 0:1 # The right hand side vector is recycled once to match the length of the 'subseted' vector
x

x[1:2] <- 10:14 # WARNING + the subset of x is modified with the first elements of the replacement vector
x

## ------------------------------------------------------------------------
x[c(1, NA)] <- c(1, 2) # You CAN'T combine integer indices with NA
x

x[c(T, F, NA)] <- 1000 # in logical indices NA are treated as false
x

## ------------------------------------------------------------------------
x <- 1:4
isOddX <- as.logical(x %% 2) # modulo 2 is not 0

x[which(isOddX)] # even numbers

x[isOddX] <- x[isOddX] + 1 # do something about odd numbers
x

## ------------------------------------------------------------------------
rev(LETTERS)

## ----ANS04---------------------------------------------------------------
LETTERS
LETTERS[length(LETTERS):1]

## ------------------------------------------------------------------------
x <- 5:8
v <- 1:4

## ----ANS06---------------------------------------------------------------
v <- c(v,x)
v

## ----ANS07---------------------------------------------------------------
v <- 1:4
v[length(v) + 1] <- x # What happen if you add more than one to the index?
v

## ----ANS08---------------------------------------------------------------
v <- 1:4
v[(length(v)+1):(length(v)+length(x))] <- x # No warning
v

## ----ANS09---------------------------------------------------------------
v <- 1:4
v <- append(v, values = x, after = 2)
v

## ----ANS10---------------------------------------------------------------
idx <- letters %in% c("a", "e", "I", "o", "u", "y")
letters[!idx]

## ------------------------------------------------------------------------
seq(from = 1, to = 6)
seq(from = 1, to = 6, by = 2)
seq(from = 1, by = 2, length.out = 3)
seq(along.with = v)
seq(5)
seq(length.out = 4)

## ------------------------------------------------------------------------
s <- c("a", "b", "c")
rep(s, times = 2)
rep(s, each = 2)
rep(s, times = 1:length(s))
rep(s, each = 3, times = 2)
rep(s, each = 2, length.out = 4)
rep(s, each = 2, length.out = 10)

## ----ANS11---------------------------------------------------------------
rep(1:3, times = 3)
rep(4:1, times = 3)
rep(1:3, each = 3)
rep(c("un", "deux"), times = c(3, 6))
rep(seq(1, 2.5, by = 0.5), each = 2, times = 2)

## ------------------------------------------------------------------------
x <- seq(1, 20, by = 2)
x

## ----ANS12---------------------------------------------------------------
x[seq(3, length(x), by = 3)]

## ----ANS13---------------------------------------------------------------
x[rep(c(FALSE, FALSE, TRUE), times = length(x)/3)]

## ------------------------------------------------------------------------
  set.seed(124)
rnorm(n = 5 , mean = 10, sd = 3)

set.seed(421)
rnorm(n = 5 , mean = 10, sd = 3)

set.seed(124)
rnorm(n = 5 , mean = 10, sd = 3)

## ------------------------------------------------------------------------
runif(n = 5, min = 0, max = 10)

## ------------------------------------------------------------------------
sample(x = month.abb, size = 5)
sample(x = month.abb, size = 13)
sample(x = month.abb, size = 13, replace = TRUE )
sample(x = c(0,1), size = 20, replace = TRUE, prob = c(0.1, 0.9))

## ------------------------------------------------------------------------
x <- c(13,5,12,5)
sort(x, decreasing = TRUE)

## ------------------------------------------------------------------------
someMonths <- c(sample(x = month.abb, size = 13, replace = TRUE ), NA)
someMonths
idx <- order(someMonths, na.last = FALSE, decreasing = FALSE) # Note the optional arguments!!
idx

## ------------------------------------------------------------------------
someMonths[idx]

## ------------------------------------------------------------------------
x <- c(3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5)
names(x) <- letters[1:11]
rank(x, ties.method = "first")
rank(x, ties.method = "average")

### ALWAYS BE AWARE OF HOW TIES ARE HANDELED!! ###

## ------------------------------------------------------------------------
x <- 1:10
y <- c(3:6, 12, 12, 15, 18)
union(x, y)
intersect(x, y)
setdiff(x, y)
setdiff(y, x)
is.element(2, x)
is.element(y, x)

let <- letters[1:2]
union(y, let) # Note the implicit type coercion

## ----ANS14---------------------------------------------------------------
x <- runif(n = 400, max = 100)
summary(x)

firstQuart <- quantile(x)[2] # 1/4 of the values in x are <= to this
med <- median(x) # or quantile(x)[3]

idx <- x > firstQuart & x < med # combine logical vectors to from an index

length(x[idx]) # subset x with index and return the lenght of this subset.
# OR
sum(idx) # logical are converted to integer

## ----ANS15---------------------------------------------------------------
ranMonths <- sample(month.name, 10, replace = TRUE)
ranMonths
months <- 1:12
names(months) <- month.name

unname(months[ranMonths])

## ----ANS16---------------------------------------------------------------
f <- c(1,-1) * rep(1:100, each = 2) # vectorized multiplication with recycling...

## ----ANS17---------------------------------------------------------------
sample(1:3, 100, prob = c(2,1,1), replace = T)

## ----ANS18---------------------------------------------------------------
#1 Create two vectors x and y...
x <- rnorm(1000, mean = 0)
y <- rnorm(1000, mean = 1)

#2 Calculate the number of pairs (x[i], y[i]) where y[i]>x[i].
sum(y > x)

#3 Calculate the number of values in y that are larger than the largest value in x.
sum(y > max(x))

#4 Calculate the number of values in x that are larger than the 200th smallest value in y and less than two standard deviations away from the mean of x.
sum(x < sort(y)[200] & abs(x - mean(x)) / sd(x) < 2)

#5 Create a vector `z` with all 999 differences between the neighboring elements of `x`...
z <- x[2:length(x)] - x[1:(length(x) - 1)]

