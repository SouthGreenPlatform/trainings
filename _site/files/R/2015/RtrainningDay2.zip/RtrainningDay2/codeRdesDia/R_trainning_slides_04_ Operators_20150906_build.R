## ----setup, include = FALSE, cache = FALSE-------------------------------
knitr::opts_chunk$set(error = TRUE, collapse = TRUE)

## ------------------------------------------------------------------------
x <- c(2, -1, 0) ; y <- 1:3
+y
-x # change the sign
x + y # addition
x - y # substraction
x * y # multiplication
x / y # division
x ^ y # power
x %% y # modulo
x %/% y # integer division


## ---- eval= FALSE--------------------------------------------------------
## ?Arithmetic
## ?sqrt
## ?complex
## ?log
## ?Trig
## ?round
## ?Special # factorial, number of combinations of k elements in n...

## ------------------------------------------------------------------------
x <- 10:5
mean(x)
median(x)
sd(x) # standard deviation
max(x)
min(x) # see also range() and parallelized pmin et pmax
sum(x)
prod(x)
length(x) # more a 'language' function but is a summary as well

## ------------------------------------------------------------------------
x <- 1:5
dplyr::lead (x)
dplyr ::lag (x)

## ------------------------------------------------------------------------
cumsum(x)
cummin(c(2:4, 0, 3:6))

## ----ANS01---------------------------------------------------------------
5^3

## ----ANS02---------------------------------------------------------------
x <- c(1:4, 1e6)
abs(x-0.5*pi)

## ------------------------------------------------------------------------
x <- c(2, 4, 6, 8)

## ----ANS03---------------------------------------------------------------
x - dplyr::lag(x)

## ------------------------------------------------------------------------
1:2 == (1+1)*(1:2)/2 # vectorized
1:2 == 1:4 # recycling if not of same length

## ------------------------------------------------------------------------
2==2L # values are coerced to a common type and tested
identical(2, 2L) # this tests object identity.
NA == 2L # makes sense...

## ------------------------------------------------------------------------
which(c(FALSE, TRUE, FALSE, TRUE))

## ------------------------------------------------------------------------
match(x =c("c", "f"), table = letters, nomatch = 0) # index of first matches of x in table
match(x = 2, table = c(1,2,3,1,2,3))
match(x = c(1,2,3,1,2,3), table = 2, nomatch = 0)
match(x = c(1,2,3,1,2,3), table = c(1,2), nomatch = 0)

## ------------------------------------------------------------------------
# all return the same thing:
match(x = c(1,2,3,1,2,3), table = c(1,2), nomatch = 0) > 0
c(1,2,3,1,2,3) %in% c(1,2) 
is.element(c(1,2,3,1,2,3), c(1,2))

## ---- eval=FALSE---------------------------------------------------------
## 0 == "0"
## 0 == FALSE

## ----ANS04---------------------------------------------------------------
"0" == FALSE

## ----ANS04.1-------------------------------------------------------------
"2" == 2

## ------------------------------------------------------------------------
v <- c(3,5)
w <- c(1,5,3,8)

## ---- ANS05--------------------------------------------------------------
v >= w

## ------------------------------------------------------------------------
x <- c(TRUE, TRUE, TRUE)
y <- c(FALSE, TRUE, FALSE, FALSE)

## ----ANS06---------------------------------------------------------------
# all()
sum(x) == length(x)
identical(sum(x) == length(x), all(x))
sum(y) == length(y)

## ----ANS07---------------------------------------------------------------
# any()
sum(y) != 0
any(y)

## ----ANS08---------------------------------------------------------------
# but, if you try that with
w <- c(FALSE, TRUE, NA, FALSE)
sum(w) != 0
any(w)

# and
sum(w) == length(w)
all(w)

# -> Need to be aware of missing values!!!
# -> A little code testing never hurts...

## ---- eval=FALSE---------------------------------------------------------
## 2*1 + 2 >= 5
## 
## 2 * (1+2) >= 5
## 
## !c("C", "logic") %in% c("A", "C", "D", "C")
## c("C", "logic") %in% c("A", "C", "D", "C")
## 
## 2*1+2 >= 5 & c("C", "logic") %in% c("A", "C", "D", "C")
## 
## !TRUE | 2*1+2 >= 5 & c("C", "logic") %in% c("A", "C", "D", "C")
## FALSE | 2*(1+2) >= 5 & c("C", "logic") %in% c("A", "C", "D", "C")
## 
## FALSE || 2*(1+2) >= 5 & c("C", "logic") %in% c("A", "C", "D", "C")
## (FALSE || 2*1+2 >= 5) & c("C", "logic") %in% c("A", "C", "D", "C")

